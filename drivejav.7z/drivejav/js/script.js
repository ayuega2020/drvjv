function hideLoading() {
    document.getElementById("loading-spinner").style.display = "none";
}

document.getElementById("hamburger").addEventListener("click", function() {
    this.classList.toggle("open");
    const menu = document.getElementById("menu");
    menu.classList.toggle("hidden");
    menu.classList.toggle("visible");
});

document.addEventListener('DOMContentLoaded', () => {
    const playlistSpans = document.querySelectorAll('.playlist span');
    const currentUrl = window.location.href;

    playlistSpans.forEach(span => {
        span.addEventListener('click', () => {
            const videoId = span.id;
            changeVideo(videoId);
            updateTitlePart(span.textContent);
        });
    });
});

function changeVideo(videoId) {
    const videoUrl = `https://www.youtube.com/embed/${videoId}`;
    const iframe = document.getElementById('main-video');
    const spinner = document.getElementById('loading-spinner');

    spinner.style.display = "block";
    iframe.src = videoUrl;
    iframe.onload = () => {
        hideLoading();
    };
}

function updateTitlePart(partText) {
    const titlePart = document.getElementById("titlePart");
    titlePart.textContent = `Part: ${partText}`;
}
